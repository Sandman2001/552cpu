# Phase 1 responsibilities

## Execute block: Andrew & Norbu

**ALU:**
- Shifter (drew)
- ALUop (norbu)
- OpFlags (drew)
- branchadder (norbu)
- reduction (norbu)
- PaddSub (drew)

## decode block:
- control
- extenstion
- register file


# Phase 2 responsibilities

**Forwarding Unit(Andrew)**

**Register Files:**
 - IF/ID reg (norbu)
 - ID/EX reg (norbu)
 - EX/MEM (collin)
 - MEM/WB (collin)

**Hazard Detection Block (Krish)**

# Krish push your shit brah

# Phase 3 responsibilities (inital deadline 4/25 (before mifflin))

**Cache:**
- interface 
- cache modules (Andrew)
- Contention management (Krish (push your shit))
- FSM (Norbu, collin)

**Testing**
  ALL
